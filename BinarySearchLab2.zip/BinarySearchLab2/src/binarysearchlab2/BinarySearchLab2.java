/*
Author:Stephanie Harders
 */
package binarysearchlab2;
import java.util.Arrays;
public class BinarySearchLab2 {

    public static void main(String[] args) {
          
    // creating small sorted array
          
        int count=0;
        int[] SSArray = new int[10];
        for (int i = 0; i < SSArray.length; i++) {  
            SSArray[i] = i;
            count=count+1;
        }
        System.out.println("The amount of steps this algo took was " + count);
        
        // binary search on small array
        int intKey=5;
         System.out.println(
            intKey + " found at index = "
            + Arrays.binarySearch(SSArray, intKey));
        
        // creating medium sorted array
        int count2=0;
        int[] MSArray = new int[100];
        for (int n = 0; n < MSArray.length; n++) {  
            MSArray[n] = n;
            count2=count2+1;
        }
        System.out.println("The amount of steps this algo took was " + count2);
        
        // binary search on medium array
        int intKey2=80;
         System.out.println(
            intKey2 + " found at index = "
            + Arrays.binarySearch(MSArray, intKey2));
 
        
        // creating large sorted array
        int count3=0;
        int[] LSArray = new int[1000];
        for (int j = 0; j < LSArray.length; j++) {  
            LSArray[j] = j;
            count3=count3+1;
        }
        System.out.println("The amount of steps this algo took was " + count3);
        
        // binary search on large array
        int intKey3=300;
         System.out.println(
            intKey3 + " found at index = "
            + Arrays.binarySearch(LSArray, intKey3));

    }
    }

    

    
    

